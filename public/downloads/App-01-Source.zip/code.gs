const SHEET_NAME = 'Incidents';

function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
      .setTitle('Báo cáo Sự cố Nội bộ')
      .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function setupSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
    sheet.appendRow(['ID', 'Người báo cáo', 'Phòng ban', 'Thời gian xảy ra', 'Địa điểm', 'Mô tả', 'Mức độ', 'Trạng thái', 'Lịch sử', 'Cập nhật lần cuối']);
    sheet.getRange("A1:J1").setFontWeight("bold");
  }
}

function submitIncident(data) {
  setupSheet();
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  
  const id = 'INC-' + new Date().getTime();
  const status = 'Mới';
  const now = new Date().toLocaleString('vi-VN');
  const history = `[${now}] Tạo mới báo cáo\n`;
  
  sheet.appendRow([
    id, data.reporter, data.department, data.time, data.location, data.description, data.severity, status, history, now
  ]);
  return true;
}

function getIncidents() {
  setupSheet();
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  const data = sheet.getDataRange().getValues();
  if (data.length <= 1) return [];
  
  const headers = data[0];
  let result = [];
  for (let i = 1; i < data.length; i++) {
    let obj = {};
    headers.forEach((h, index) => obj[h] = data[i][index]);
    result.push(obj);
  }
  
  // Ưu tiên hiển thị Mức độ Nghiêm trọng lên đầu, sau đó sắp xếp theo thời gian mới nhất
  result.sort((a, b) => {
    if (a['Mức độ'] === 'Nghiêm trọng' && b['Mức độ'] !== 'Nghiêm trọng') return -1;
    if (a['Mức độ'] !== 'Nghiêm trọng' && b['Mức độ'] === 'Nghiêm trọng') return 1;
    return new Date(b['Cập nhật lần cuối']) - new Date(a['Cập nhật lần cuối']);
  });
  return result;
}

function updateStatus(id, newStatus, role) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  const data = sheet.getDataRange().getValues();
  
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === id) {
      const now = new Date().toLocaleString('vi-VN');
      let currentHistory = data[i][8] || '';
      currentHistory += `[${now}] ${role} đổi thành: ${newStatus}\n`;
      
      sheet.getRange(i + 1, 8).setValue(newStatus);
      sheet.getRange(i + 1, 9).setValue(currentHistory);
      sheet.getRange(i + 1, 10).setValue(now);
      return true;
    }
  }
  return false;
}