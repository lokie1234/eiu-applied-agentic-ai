const SHEET_NAME = 'Quản lý nghỉ phép';

function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
      .setTitle('Demo Quản Lý Nghỉ Phép')
      .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

// Hàm khởi tạo Sheet và lấy Sheet active
function setupSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
    sheet.appendRow(['ID', 'Họ tên', 'Từ ngày', 'Đến ngày', 'Lý do', 'Trạng thái', 'Thời gian gửi']);
    sheet.getRange("A1:G1").setFontWeight("bold");
  }
  return sheet;
}

// Lưu đơn mới
function submitLeave(data) {
  const sheet = setupSheet();
  const id = 'NP-' + new Date().getTime();
  const timestamp = new Date().toLocaleString('vi-VN');
  sheet.appendRow([id, data.name, data.startDate, data.endDate, data.reason, 'Chờ duyệt', timestamp]);
  return true;
}

// Lấy danh sách đơn
function getLeaves() {
  const sheet = setupSheet();
  const data = sheet.getDataRange().getDisplayValues();
  if (data.length <= 1) return [];
  
  let result = [];
  const headers = data[0];
  // Duyệt từ dưới lên để đơn mới nhất hiển thị trước
  for (let i = data.length - 1; i >= 1; i--) {
    let obj = { row: i + 1 }; // Lưu lại số thứ tự dòng để dễ update
    headers.forEach((h, index) => obj[h] = data[i][index]);
    result.push(obj);
  }
  return result;
}

// Cập nhật trạng thái
function updateStatus(row, newStatus) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  sheet.getRange(row, 6).setValue(newStatus); // Cột F (cột số 6) là Trạng thái
  return true;
}